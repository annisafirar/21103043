
package UTSPBO_NO3_SI05B_3043;

public class Mahasiswa_3043 {

    protected String nim;
    protected String nama;
    protected String jurusan;
    protected int ipk;

    public void Tampil_Data_Mahasiswa() {
        System.out.println(" NIM    : " + nim);
        System.out.println("Nama    " + nama);
        System.out.println("Jurusan    : " + jurusan);
        System.out.println("IPK : " + ipk);
    }
}
