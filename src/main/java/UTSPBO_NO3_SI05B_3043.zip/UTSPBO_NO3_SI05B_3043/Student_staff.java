
package UTSPBO_NO3_SI05B_3043;


public class Student_staff extends Mahasiswa_3043 {
    int unitKerja, jamKerja;
    
    public double totalPendapatan(){
        return (jamKerja * 30000);
    }
    public void tampilDataStudentStaff(){
        super.Tampil_Data_Mahasiswa();
        System.out.println(" Unit Kerja : " + unitKerja);
        System.out.println(" Jam Kerja : " +jamKerja);
        System.out.println(" Total Pendapatan Student Staff : " +totalPendapatan());
    }
}
 
