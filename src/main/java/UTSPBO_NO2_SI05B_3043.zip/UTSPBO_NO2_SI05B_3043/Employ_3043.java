
package UTSPBO_NO2_SI05B_3043;


public class Employ_3043  {
 
      protected String Nama;
    protected String NIP;
    protected float GajiPokok;
    
    public void Tampil(){
        System.out.println("Nama: " + Nama);
        System.out.println("NIP: " + NIP);
        System.out.println("Gaji Pokok: " + GajiPokok);
    }
}

