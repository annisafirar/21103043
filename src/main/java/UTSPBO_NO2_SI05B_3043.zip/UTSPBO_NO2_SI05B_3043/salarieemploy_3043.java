/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UTSPBO_NO2_SI05B_3043;

/**
 *
 * @author LENOVO
 */
public class salarieemploy_3043 extends Employ_3043 {

    public salarieemploy_3043 (){
        
    }
        public void TampilData(){
        System.out.println("Salaried Employee");
        Tampil();
        System.out.println("Total Gaji: " + GajiPokok);

    }
}
