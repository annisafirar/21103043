/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UTSPBO_NO2_SI05B_3043;

/**
 *
 * @author LENOVO
 */
public class CommissionEmploy_3043 extends Employ_3043{
public float Komisi;
    public float TotalPenjualan;
    public float Totalgaji;
    
    public CommissionEmploy_3043(){
        
    }
    
    public float TotalGaji(){
        Totalgaji = GajiPokok + (Komisi * TotalPenjualan);
        return Totalgaji;
    }
    
    public void TampilData(){
        System.out.println("Commission Employee");
        Tampil();
        System.out.println("Total Gaji: " + Totalgaji);
    }
}
